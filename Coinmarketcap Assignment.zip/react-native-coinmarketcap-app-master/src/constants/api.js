export const API_KEY = 'a0257b11-b76b-4274-8654-c57c319cdf68'
export const LIMIT_PER_PAGE = 100
